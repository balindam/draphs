#ifndef TEACHER_H_INCLUDED
#define TEACHER_H_INCLUDED

void teacher_main();

void student_main();

#endif // TEACHER_H_INCLUDED

